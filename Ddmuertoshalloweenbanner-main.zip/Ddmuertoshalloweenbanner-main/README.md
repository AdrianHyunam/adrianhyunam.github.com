
  # Día de Muertos Halloween Banner

  This is a code bundle for Día de Muertos Halloween Banner. The original project is available at https://www.figma.com/design/MEYtKyMIXqKEDgYLXA8NRN/D%C3%ADa-de-Muertos-Halloween-Banner.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  